#include <iostream>
#include <boost/interprocess/sync/named_sharable_mutex.hpp>
#include <boost/interprocess/sync/sharable_lock.hpp>
#include <boost/interprocess/managed_shared_memory.hpp>
#include <boost/interprocess/sync/scoped_lock.hpp>
#include <boost/interprocess/shared_memory_object.hpp>

int main()
{
	using namespace boost::interprocess;

	managed_shared_memory managed_shm(open_or_create, "hello", 1024*1024); 
	named_sharable_mutex named_shared_mtx(open_or_create, "sharedmutex");

	std::pair<int*, std::size_t> p = managed_shm.find<int>("Integer"); 
	if (p.first) 
	{ 
		for(;;)
		{
			// named_shared_mtx.lock_sharable();
			//sharable_lock后的mutex不是独占式的，多个进程可以同时对mutex加sharable_lock
			//但是当有一个进程对mutex加了独占锁（scoped_lock或lock）,则下面语句阻塞
			sharable_lock<named_sharable_mutex> mylock(named_shared_mtx);
			if(mylock)
			{
				std::cout << "read: " << *(p.first + 88) << std::endl;
				//手动解锁
				mylock.unlock();
			}
			sleep(1);
			// named_shared_mtx.unlock_sharable();
		}
	} 

	return 0;
}