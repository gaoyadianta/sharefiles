#include <iostream>
#include <boost/interprocess/sync/named_sharable_mutex.hpp>
#include <boost/interprocess/sync/sharable_lock.hpp>
#include <boost/interprocess/managed_shared_memory.hpp>
#include <boost/interprocess/sync/scoped_lock.hpp>
#include <boost/interprocess/shared_memory_object.hpp>

namespace bi = boost::interprocess;

int main()
{
	// using namespace boost::interprocess;

	//构造一个共享内存，id叫做“hello”，大小是1024×1024字节
	bi::managed_shared_memory managed_shm(bi::open_or_create, "hello", 1024*1024); 
	//构造一个named_sharable_mutex，名字叫做sharedmutex，由内核管理
	bi::named_sharable_mutex named_shared_mtx(bi::open_or_create, "sharedmutex");
	//在共享内存中找到一个int[1000]的对象，名字叫做“Integer”，如果找不到则创建它
	int *shm_ptr = managed_shm.find_or_construct<int>("Integer")[1000](99);	

	//成功
	if (shm_ptr != NULL) 
	{
		//Interger数据初始化 
		for(int i=0; i<1000; i++)
			*(shm_ptr + i) = i;
	} 
	else
	{
		return 1;
	}	

	for(;;)
	{
		// sharable_lock<named_sharable_mutex> mylock(named_shared_mtx);
		//将"sharedmutex"上独占锁，当lock成功后，任何其他进程均不能获取"sharedmutex"
		bi::scoped_lock<bi::named_sharable_mutex> mylock(named_shared_mtx);
		//上锁成功
		if(mylock)
		{
			//在独占锁住"sharedmutex"的情况下，写“Integer”中的数据
			*(shm_ptr + 88) += 1;
			std::cout << "write: " << *(shm_ptr + 88) << std::endl;
			//手动解锁，让其他进程可以访问数据
			mylock.unlock();
		}
		sleep(1);
	}
	return 0;
}
