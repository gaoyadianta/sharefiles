#include <iostream>
#include <boost/interprocess/sync/named_sharable_mutex.hpp>
#include <boost/interprocess/sync/sharable_lock.hpp>
#include <boost/interprocess/managed_shared_memory.hpp>
#include <boost/interprocess/sync/scoped_lock.hpp>
#include <boost/interprocess/shared_memory_object.hpp>

int main()
{
	using namespace boost::interprocess;
	//删除共享内存和mutex，防止在初始化的时候已经存在了之前未删除的共享内存和mutex
	shared_memory_object::remove("hello"); 
	shared_memory_object::remove("sharedmutex");

	//构造一个共享内存，id叫做“hello”，大小是1024×1024字节
	managed_shared_memory managed_shm(open_or_create, "hello", 1024*1024); 
	//构造一个named_sharable_mutex，名字叫做sharedmutex，由内核管理
	named_sharable_mutex named_shared_mtx(open_or_create, "sharedmutex");
	//在共享内存中构造一个int[1000]的对象，名字叫做“Integer”
	int *i = managed_shm.construct<int>("Integer")[1000](99); 
	//p.first是“Integer”在共享内存的地址，p.second是1000
	std::pair<int*, std::size_t> p = managed_shm.find<int>("Integer"); 
	//成功
	if (p.first) 
	{
		//Interger数据初始化 
		for(int i=0; i<1000; i++)
			*(p.first + i) = i;
	} 
	else
		return 1;

	for(;;)
	{
		// sharable_lock<named_sharable_mutex> mylock(named_shared_mtx);
		//将"sharedmutex"上独占锁，当lock成功后，任何其他进程均不能获取"sharedmutex"
		scoped_lock<named_sharable_mutex> mylock(named_shared_mtx);
		//上锁成功
		if(mylock)
		{
			//在独占锁住"sharedmutex"的情况下，写“Integer”中的数据
			*(p.first + 88) += 1;
			std::cout << "write: " << *(p.first + 88) << std::endl;
			//手动解锁，让其他进程可以访问数据
			mylock.unlock();
		}
		sleep(1);
	}
	return 0;
}