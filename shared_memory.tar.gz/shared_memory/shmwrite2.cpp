#include <iostream>
#include <boost/interprocess/sync/named_sharable_mutex.hpp>
#include <boost/interprocess/sync/sharable_lock.hpp>
#include <boost/interprocess/managed_shared_memory.hpp>
#include <boost/interprocess/sync/scoped_lock.hpp>
#include <boost/interprocess/shared_memory_object.hpp>

int main()
{
	using namespace boost::interprocess;
	//创建或打开名为hello的共享内存
	managed_shared_memory managed_shm(open_or_create, "hello", 1024*1024); 
	//打开名为sharedmutex的mutex
	named_sharable_mutex named_shared_mtx(open_only, "sharedmutex");
	
	//找到名为Integer的int[1000]的对象，将其映射至本进程
	std::pair<int*, std::size_t> p = managed_shm.find<int>("Integer"); 
	if (p.first) 
	{ //映射成功
		for(;;)
		{
			//将"sharedmutex"上独占锁，当lock成功后，任何其他进程均不能获取"sharedmutex"
            scoped_lock<named_sharable_mutex> mylock(named_shared_mtx);
            if(mylock)
            {//上锁成功
				//在独占锁住"sharedmutex"的情况下，写“Integer”中的数据
                *(p.first + 88) += 1;
                std::cout << "write: " << *(p.first + 88) << std::endl;
				//手动解锁，让其他进程可以访问数据
                mylock.unlock();
            }
            sleep(1);

		}
	} 

	return 0;
}