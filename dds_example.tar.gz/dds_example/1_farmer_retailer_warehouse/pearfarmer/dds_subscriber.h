#ifndef DDS_SUBSCRIBER_H_
#define DDS_SUBSCRIBER_H_

#include <fastrtps/attributes/SubscriberAttributes.h>
#include <fastrtps/subscriber/SubscriberListener.h>
#include <fastrtps/subscriber/Subscriber.h>
#include <fastrtps/Domain.h>
#include <fastrtps/subscriber/SampleInfo.h>

template <typename T, typename M>
class DdsSubscriber
{
public:
    DdsSubscriber():mp_subscriber_(nullptr),mp_participant_(nullptr){};
    virtual ~DdsSubscriber(){};
    bool Create(DdsParticipant &participant_ref,
        const std::string& datatype, 
        const std::string& topicname, 
        uint32_t history,
        void(*callback_ptr)(T *))
    {
        mp_participant_ = participant_ref.get_participant_ptr();
        eprosima::fastrtps::Domain::registerType(mp_participant_,&m_type_);
        m_listener_.callback_pointer_ = callback_ptr;
        eprosima::fastrtps::SubscriberAttributes Rparam;
        Rparam.topic.topicKind = eprosima::fastrtps::NO_KEY;
        Rparam.topic.topicDataType = datatype;
        Rparam.topic.topicName = topicname;
        Rparam.topic.historyQos.kind = eprosima::fastrtps::KEEP_LAST_HISTORY_QOS;
        Rparam.topic.historyQos.depth = history;
        Rparam.topic.resourceLimitsQos.max_samples = 200;
        Rparam.qos.m_reliability.kind = eprosima::fastrtps::RELIABLE_RELIABILITY_QOS;
        Rparam.qos.m_durability.kind = eprosima::fastrtps::TRANSIENT_LOCAL_DURABILITY_QOS;
        mp_subscriber_ = eprosima::fastrtps::Domain::createSubscriber(mp_participant_,
            Rparam,
            (eprosima::fastrtps::SubscriberListener*)&m_listener_);
        if(mp_subscriber_ == nullptr)
            return false;
            
        return true;
    };
    bool Create(DdsParticipant &participant_ref,
        const std::string& xml_profile_name,
        void(*callback_ptr)(T *))
    {
        mp_participant_ = participant_ref.get_participant_ptr();
        eprosima::fastrtps::Domain::registerType(mp_participant_,&m_type_);
        m_listener_.callback_pointer_ = callback_ptr;

        mp_subscriber_ = eprosima::fastrtps::Domain::createSubscriber(mp_participant_, 
            xml_profile_name,
            (eprosima::fastrtps::SubscriberListener*)&m_listener_);
        if(mp_subscriber_ == nullptr)
            return false;

        return true;
    };

private:
    eprosima::fastrtps::Participant* mp_participant_;
    eprosima::fastrtps::Subscriber* mp_subscriber_;
    M m_type_;
public:
	class SubListener:public eprosima::fastrtps::SubscriberListener
	{
	public:
		SubListener(){};
		~SubListener(){};
		void onNewDataMessage(eprosima::fastrtps::Subscriber* sub)
        {
            if(sub->takeNextData((void*)&m_data_, &m_info_))
            {
                if(m_info_.sampleKind == eprosima::fastrtps::ALIVE)
                {
                    callback_pointer_(&m_data_);
                }
            }
        };
        eprosima::fastrtps::SampleInfo_t m_info_;
		T m_data_;
        void(*callback_pointer_)(T *);
	}m_listener_;
};

#endif /*end of DDS_SUBSCRIBER_H_*/