#ifndef DDS_PUBLISHER_H_
#define DDS_PUBLISHER_H_

#include <fastrtps/attributes/PublisherAttributes.h>
#include <fastrtps/publisher/PublisherListener.h>
#include <fastrtps/publisher/Publisher.h>
#include <fastrtps/Domain.h>
#include <thread>

// using namespace eprosima::fastrtps;
// using namespace eprosima::fastrtps::rtps;

template <typename T, typename M>
class DdsPublisher
{
public:
    DdsPublisher():mp_publisher_(nullptr),mp_participant_(nullptr){};
    virtual ~DdsPublisher(){};
    bool Create(DdsParticipant &participant_ref,
        const std::string& datatype, 
        const std::string& topicname, 
        uint32_t history)
    {
        mp_participant_ = participant_ref.get_participant_ptr();
        eprosima::fastrtps::Domain::registerType(mp_participant_,&m_type_);

        eprosima::fastrtps::PublisherAttributes Wparam;
        Wparam.topic.topicKind = eprosima::fastrtps::NO_KEY;
        Wparam.topic.topicDataType = datatype;
        Wparam.topic.topicName = topicname;
        Wparam.topic.historyQos.kind = eprosima::fastrtps::KEEP_LAST_HISTORY_QOS;
        Wparam.topic.historyQos.depth = history;
        Wparam.topic.resourceLimitsQos.max_samples = 200;
        Wparam.qos.m_reliability.kind = eprosima::fastrtps::RELIABLE_RELIABILITY_QOS;
        mp_publisher_ = eprosima::fastrtps::Domain::createPublisher(mp_participant_, 
            Wparam,
            (eprosima::fastrtps::PublisherListener*)&m_listener_);
        if(mp_publisher_ == nullptr)
            return false;

        return true;
    };

    bool Create(DdsParticipant &participant_ref,
        const std::string& xml_profile_name)
    {
        mp_participant_ = participant_ref.get_participant_ptr();
        eprosima::fastrtps::Domain::registerType(mp_participant_,&m_type_);

        mp_publisher_ = eprosima::fastrtps::Domain::createPublisher(mp_participant_, 
            xml_profile_name,
            (eprosima::fastrtps::PublisherListener*)&m_listener_);
        if(mp_publisher_ == nullptr)
            return false;

        return true;
    };

    bool PublishDds(T *t_ptr)
    {
        mp_publisher_->write((void*)t_ptr);
    };
private:
    eprosima::fastrtps::Participant* mp_participant_;
    eprosima::fastrtps::Publisher* mp_publisher_;
    M m_type_;
	class PubListener:public eprosima::fastrtps::PublisherListener
	{
	public:
		PubListener(){};
		~PubListener(){};
		void onPublicationMatched(eprosima::fastrtps::Publisher* pub, eprosima::fastrtps::rtps::MatchingInfo& info){};
	}m_listener_;
};

#endif /*end of DDS_PUBLISHER_H_*/