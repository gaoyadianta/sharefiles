//包含dds服务的头文件
#include "dds_participant.h"
#include "dds_publisher.h"
#include "dds_subscriber.h"
//包含topic和消息的头文件
#include "pear.h"
#include "pearPubSubTypes.h"

#include <thread>
#include <iostream>
#include <unistd.h>

using namespace std;

int main(int argc, char** argv)
{
    //构造一个Pear的对象，这个对象即publish出去的内容
    Pear my_pear;
    //初始化数据
    my_pear.number(1);
    //创建一个participant
    DdsParticipant my_participant;
    my_participant.Create("helloparticipant", 100);
    //创建一个publisher，并指定topic的名字和topic的数据类型
    DdsPublisher<Pear, PearPubSubType> my_pub;
    /*第一个参数是DdsParticipant构造的对象，第二个参数是消息的数据类型（必须与消息类完全一样）， 第三个参数是topic的名字，
    *这个参数需要与subscriber端一致消息才能被正确传递，第四个参数是history，表示fastrtps会记录多少条历史数据*/
    my_pub.Create(my_participant, "Pear", "PearTopic", 1);
    for(;;)
    {
        //publish数据
        my_pub.PublishDds(&my_pear);
        cout << "Pearfarmer published pear number: " << my_pear.number() << endl;
        my_pear.number(my_pear.number() + 2);
        sleep(3);
    }
    return 0;
}
