#include "dds_participant.h"
#include "dds_publisher.h"
#include "dds_subscriber.h"

#include "apple.h"
#include "pear.h"
#include "storage.h"
#include "applePubSubTypes.h"
#include "pearPubSubTypes.h"
#include "storagePubSubTypes.h"

#include <iostream>
#include <unistd.h>

using namespace std;

void SubNewAppleDateArrived(Apple *recerived_data);
void SubNewPearDateArrived(Pear *recerived_data);

Storage my_storage;

int main(int argc, char** argv)
{
    my_storage.totalnum(0);
    //创建一个participant
    DdsParticipant my_participant;
    my_participant.Create("Retailerparticipant", 100);
    //创建一个publisher，用于在StorageTopic发送Storage消息
    DdsPublisher<Storage, StoragePubSubType> my_pub;
    my_pub.Create(my_participant, "Storage", "StorageTopic", 1);
    //创建一个subscriber，用于订阅AppleTopic的Apple消息
    DdsSubscriber<Apple, ApplePubSubType> my_apple_sub;
    my_apple_sub.Create(my_participant, "Apple", "AppleTopic", 1, SubNewAppleDateArrived);
    //创建一个subscriber，用于订阅PearTopic的Pear消息
    DdsSubscriber<Pear, PearPubSubType> my_pear_sub;
    my_pear_sub.Create(my_participant, "Pear", "PearTopic", 1, SubNewPearDateArrived);

    std::cout << "Subscriber running..." << std::endl;
    
    for(;;)
    {
        //每隔5秒向StorageTopic publish一个Storage消息
        my_pub.PublishDds(&my_storage);
        cout << "Retailer published total number: " << my_storage.totalnum() << endl;
        sleep(5);
    }

    return 0;
}
//接收到AppleTopic的Apple消息的回调函数
void SubNewAppleDateArrived(Apple *recerived_data)
{
    std::cout << "Apple topic data received: " << recerived_data->number() << std::endl;
    my_storage.totalnum(my_storage.totalnum() + recerived_data->number());
}
//接收到PearTopic的Pear消息的回调函数
void SubNewPearDateArrived(Pear *recerived_data)
{
    std::cout << "Pear topic data received: " << recerived_data->number() << std::endl;
    my_storage.totalnum(my_storage.totalnum() + recerived_data->number());
}