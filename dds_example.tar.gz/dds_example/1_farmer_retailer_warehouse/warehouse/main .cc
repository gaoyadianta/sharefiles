//包含dds服务的头文件
#include "dds_participant.h"
#include "dds_publisher.h"
#include "dds_subscriber.h"
//包含topic和消息的头文件
#include "storage.h"
#include "storagePubSubTypes.h"

#include <iostream>
#include <unistd.h>

using namespace std;

//接受到订阅的消息时的回调函数
void SubNewDateArrived(Storage *recerived_data);

int main(int argc, char** argv)
{
    //创建一个participant
    DdsParticipant my_participant;
    my_participant.Create("Warehouseparticipant", 100);
    //创建一个publisher，这个publisher用于在StorageTopic中发布Storage消息
    DdsSubscriber<Storage, StoragePubSubType> my_sub;
    /*第一个参数是DdsParticipant构造的对象，第二个参数是消息的数据类型（必须与消息类完全一样）， 第三个参数是topic的名字，
    这个参数需要与publisher端一致消息才能被正确传递，第四个参数是history，表示fastrtps会记录多少条历史数据，第五个
    参数是回调函数的指针*/
    my_sub.Create(my_participant, "Storage", "StorageTopic", 2, SubNewDateArrived);


    std::cout << "Subscriber running..." << std::endl;
    std::cin.ignore();

    return 0;
}
//回调函数的实现
void SubNewDateArrived(Storage *recerived_data)
{
    std::cout << "Warehouse received totalnum: " << recerived_data->totalnum() << std::endl;
}