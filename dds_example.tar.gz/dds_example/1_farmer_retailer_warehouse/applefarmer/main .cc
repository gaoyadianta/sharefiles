//包含dds服务的头文件
#include "dds_participant.h"
#include "dds_publisher.h"
#include "dds_subscriber.h"
//包含topic和消息的头文件
#include "apple.h"
#include "applePubSubTypes.h"

#include <thread>
#include <iostream>
#include <unistd.h>

using namespace eprosima;
using namespace fastrtps;
using namespace rtps;
using namespace std;

void SubNewDateArrived(Apple *recerived_data);

int main(int argc, char** argv)
{
    //构造一个Apple的对象，这个对象即publish出去的内容
    Apple my_apple;
    //初始化数据
    my_apple.number(3);
    //创建一个participant
    DdsParticipant my_participant;
    eprosima::fastrtps::Participant* my_part_ptr = my_participant.Create("helloparticipant", 100);
    //创建一个publisher，并指定topic的名字和topic的数据类型
    DdsPublisher<Apple, ApplePubSubType> my_pub;
    /*第一个参数是participant的指针，第二个参数是消息的数据类型（必须与消息类完全一样）， 第三个参数是topic的名字，
    *这个参数需要与subscriber端一致消息才能被正确传递，第四个参数是history，表示fastrtps会记录多少条历史数据*/
    my_pub.Create(my_part_ptr, "Apple", "AppleTopic", 1);
    for(;;)
    {
        //publish数据
        my_pub.PublishDds(&my_apple);
        cout << "Applefarmer published apple number: " << my_apple.number() << endl;
        my_apple.number(my_apple.number() + 1);
        sleep(1);
    }
    Domain::stopAll();
    return 0;
}