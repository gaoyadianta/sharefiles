//包含dds服务的头文件
#include "dds_participant.h"
#include "dds_publisher.h"
#include "dds_subscriber.h"
//包含topic和消息的头文件
#include "imu.h"
#include "imuPubSubTypes.h"

#include <thread>
#include <iostream>
#include <unistd.h>

using namespace eprosima;
using namespace fastrtps;
using namespace rtps;
using namespace std;

int main(int argc, char** argv)
{
    //构造一个Imu的对象，这个对象即publish出去的内容
    Imu my_imu;
    //初始化数据
    my_imu.yaw(3.0);
    //载入配置用的XML文件（默认路径是可执行文件所在的路径）
	xmlparser::XMLProfileManager::loadXMLFile("imu.xml");
    //创建一个participant
    DdsParticipant my_participant;
    eprosima::fastrtps::Participant* my_part_ptr = my_participant.Create("helloparticipant", 100);
    //创建一个publisher，并指定topic的名字和topic的数据类型
    DdsPublisher<Imu, ImuPubSubType> my_pub;
    /*第一个参数是participant的指针，第二个参数是xml文件中的profile*/
    my_pub.Create(my_part_ptr, "imu_publisher_profile");
    for(;;)
    {
        //publish数据
        my_pub.PublishDds(&my_imu);
        cout << "ImuPub published imu.yaw: " << my_imu.yaw() << endl;
        my_imu.yaw(my_imu.yaw() + 1);
        sleep(1);
    }
    Domain::stopAll();
    return 0;
}