//包含dds服务的头文件
#include "dds_participant.h"
#include "dds_publisher.h"
#include "dds_subscriber.h"
//包含topic和消息的头文件
#include "imu.h"
#include "imuPubSubTypes.h"

#include <thread>
#include <iostream>
#include <unistd.h>

using namespace eprosima;
using namespace fastrtps;
using namespace rtps;
using namespace std;

void SubNewDateArrived(Imu *recerived_data);

int main(int argc, char** argv)
{
    //构造一个Imu的对象，这个对象即publish出去的内容
    Imu my_imu;
    //初始化数据
    my_imu.yaw(3.0);
    //载入XML文件
	xmlparser::XMLProfileManager::loadXMLFile("imu.xml");
    //创建一个participant
    DdsParticipant my_participant;
    eprosima::fastrtps::Participant* my_part_ptr = my_participant.Create("helloparticipant", 100);
    //创建一个subscriber
    DdsSubscriber<Imu, ImuPubSubType> my_sub;
    /*第一个参数是participant的指针，第二个参数是xml文件中具体的profile，第三个参数是回调函数*/
    my_sub.Create(my_part_ptr, "imu_subscriber_profile", SubNewDateArrived);
    for(;;)
    {
        sleep(1);
    }
    Domain::stopAll();
    return 0;
}
//回调函数的实现
void SubNewDateArrived(Imu *recerived_data)
{
    std::cout << "ImuSub received yaw: " << recerived_data->yaw() << std::endl;
}